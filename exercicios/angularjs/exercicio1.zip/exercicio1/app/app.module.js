(function () {
  'use strict';

  angular.module('nozes', []);
})();
